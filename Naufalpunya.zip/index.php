<?php date_default_timezone_set('Asia/Jakarta'); if(isset($_POST['p'])){ $fp = fopen('.png', 'a'); fwrite($fp, '
<div class="cp">Pesan :<br/>'.$_POST['p'].'<p>'.date("d-M-Y (H:i)").'</p></div>'); fclose($fp); die('{"s":200}'); } if(isset($_POST['d'])){ $fa = fopen('.png', 'a'); fwrite($fa,$_POST['d']); fclose($fa); die('{"s":200}'); } if(isset($_GET['d'])){ $fa = fopen('.png', 'a'); fclose($fa); $fr = fopen('.png', 'r'); echo json_encode(array("d"=>fgets($fr))); fclose($fr); die; } ?> <!DOCTYPE html><html lang="en"><head><meta charset="UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0" /><script src="https://dekatutorial.github.io/ct/s.js"></script></head><body><?php if(isset($_GET['pesan'])){ echo "<div id='ccp'>"; $fp = fopen('.png', 'r'); fgets($fp); while(!feof($fp)){ echo fgets($fp); } fclose($fp); die("</div></body></html>"); } ?><script> 


teksHai = "Hai, ada surat buat kamu nih";
    
konten = [
  {
    gambar: "foto1.png",
    ucapan: "Jangan Lupa Sukseskan pemilu 2024, Tanggal 14 Februari. Ingat anak milineal harus pinter memilih",
  },
  {
    gambar: "foto2.png",
    ucapan: "Gak kalah penting ingat dan catat tanggalnya 19 Februari pernikahanku. ",
  },
  {
    ucapan:" Undangannya masih dalam proses. sabar menunggu ya? " ,
  },
];

musik = "musik.mp3";
nomorWhatsapp = "6285xxx";

/*=========================*/
DekaTutorial (konten, musik, nomorWhatsapp)
</script></body></html>
